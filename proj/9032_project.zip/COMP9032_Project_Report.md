# Clinic Management Kiosk Prototype

## Introduction

Welcome to the Clinic Management Kiosk Prototype manual. This kiosk is designed to streamline patient check-ins at your medical clinic by allowing patients to add themselves to the queue upon arrival. The kiosk features a user-friendly interface with an LCD display and a 4-by-4 matrix keypad, enabling patients to enter their names using a familiar mobile phone-style input method. The kiosk also includes an LED panel and a bell system to enhance patient communication. The LED panel provides visual cues, such as estimated wait times, and synchronizes with the bell for attention alerts. The secondary LCD display mirrors the primary LCD’s content in 'display' mode and retains its state during 'entry' mode. Additionally, the bell offers three distinct tones for notifying patients, each synchronized with LED flashes. The kiosk also features two buttons for the doctor’s interaction to efficiently manage patient flow.

This manual provides detailed instructions on how to operate the kiosk, focusing on keypad input handling, LCD display functionalities, and the synchronization between the primary and secondary LCD displays. This manual additionally outlines the integration of the LED panel, bell, and dual-LCD functionalities. It details the operational modes, describes how patients interact with the kiosk, and explains the roles of the doctor in managing the system efficiently.

---

## Step-by-Step Instructions to Operate the Prototype

### 1. Starting the Kiosk

- **Power On:** When the clinic opens, turn on the kiosk system. The kiosk will initialize and display the default screen in **'display' mode**, showing the next patient in the queue.

---

### 2. Adding a Patient to the Queue

Patients can easily add themselves to the queue using the following steps:

#### a. Initiating Entry Mode

- **Press Key 'A':** On the keypad, press the key labeled **'A'** to start the check-in process.
- **Mode Switch:** The kiosk switches from **'display' mode** to **'entry' mode**.
- **Prompt Displayed:** The main LCD displays a prompt for name entry.

  **LCD Display:**

  ```
  Enter Name:
  ```

#### b. Entering the Patient's Name

- **Using Keys 2–9:** Enter your name using keys **2** to **9**, similar to texting on a classic mobile phone.

  **Keypad Character Mapping:**

  | Key | Characters     |
  |-----|----------------|
  | 2   | A, B, C        |
  | 3   | D, E, F        |
  | 4   | G, H, I        |
  | 5   | J, K, L        |
  | 6   | M, N, O        |
  | 7   | P, Q, R, S     |
  | 8   | T, U, V        |
  | 9   | W, X, Y, Z     |

- **Character Selection:** Press the key repeatedly to cycle through the letters.

  **Example:**

  - To enter 'C', press **2** three times.
  - To enter 'N', press **6** twice.

- **Real-Time Display:** The selected character appears on the second line of the LCD.

  **LCD Display:**

  ```
  Enter Name:
  J
  ```

#### c. Editing the Input

- **Backspace (Key 'B'):** Press to delete the last character if a mistake is made.
- **Clear (Key 'C'):** Press to erase the entire input and start over.

#### d. Confirming the Input

- **Done (Key 'D'):** After entering the full name, press **'D'** to submit.
- **Confirmation Message:** The kiosk displays a message with your name and assigned patient number.

  **LCD Display:**

  ```
  Confirm Data:
  John           5
  ```

#### e. Completing the Process

- **Acknowledge (Press 'D' Again):** Press **'D'** to confirm you have noted your patient number.
- **Return to Display Mode:** The kiosk reverts to **'display' mode**, ready for the next patient.

---

### 3. Viewing Queue Information

- **Next Patient Display:** In **'display' mode**, the kiosk shows the next patient in the queue.

  **LCD Display:**

  ```
  Next Patient:
  Jane           4
  ```

- **Secondary LCD:** The wall-mounted secondary LCD mirrors this information, ensuring all waiting patients are informed.

---

### 4. Handling Special Keys and Modes

- **Key 'A':** Starts the check-in process.
- **Key 'B':** Acts as a backspace during name entry.
- **Key 'C':** Clears the current input.
- **Key 'D':** Confirms name entry and acknowledges the patient number.
- **Keys 2–9:** Used for entering letters corresponding to each key.

---

### 5. Button Control

#### a. Next Patient Button (PB0):
   
  - Pressing this button calls the next patient in the queue.
  If patients are waiting, the bell plays a Beep-beep tone for 10 seconds, followed by a continuous Bip-bip tone until the doctor takes further action. Simultaneously, the LED panel flashes in sync with the bell tones.
  - When the patient arrives at the consultation room, the doctor holds the button for one second to stop the tones and LED flashes and update the display with the next patient’s details.
  - If the kiosk is in ‘entry’ mode, it temporarily switches to ‘display’ mode to process the update and returns to ‘entry’ mode five seconds later.
  - If no patients are waiting, the button press has no effect.

#### b. Cancel Appointment Button (PB1):

  - This button cancels the current patient’s appointment if they do not arrive.
  - Holding the button for one second triggers a Bee…eep tone and synchronized LED flash for 3 seconds.
  - Afterward, the system updates the display with the next patient’s details and resumes as though the Next Patient button was pressed.

---

### 5. LED Panel and Bell Notifications

#### a. Bell Notifications:

The kiosk uses a bell system with three distinct tones to signal different events:

- Beep-beep: A 1-second ON and 1-second OFF tone to attract the attention of the next patient when called.
- Bip-bip: A 0.5-second ON and 0.5-second OFF tone, used to signal that the next patient should proceed to the consultation room.
- Bee...eep: A 3-second ON tone followed by an OFF signal, used when an appointment is canceled.
The bell tones are synchronized with the LED panel, ensuring patients are visually guided alongside auditory cues.

#### b.LED Panel Visual Indicators:

The LED panel serves as a dynamic visual aid. It flashes in sync with the bell tones during the following events:

- Next Patient Call: LEDs flash alternately with the Beep-beep and Bip-bip tones until the patient arrives or the doctor takes further action.
- Appointment Cancellation: LEDs flash continuously for 3 seconds in sync with the Bee...eep tone.
  
During idle periods, the LED panel displays the estimated waiting time for the next patient by illuminating a proportional number of LEDs based on the remaining time.

---
## Appendices

### A. Project Timeline

**Week 1:**

- **Keypad Input Handling:**
  - Implemented keypad scanning and detection logic.
  - Developed mobile-style input for patient names.
  - Tested basic keypad functionality with the LCD.
- **LED Panel Control:**
  - Programmed LED panel to display estimated wait times.
- **Bell Notifications:**
  - Configured three distinct bell tones for patient alerts.

**Week 2:**

- **Special Key Functions:**
  - Implemented 'B' for backspace, 'C' for clear, and 'D' for done.
- **LCD Display Control:**
  - Created prompts and messages for patient interaction.
  - Managed transitions between 'entry' and 'display' modes.
- **Dual LCD Synchronization:**
  - Established logic to sync displays based on kiosk mode.
  - Ensured privacy by preventing updates to the secondary LCD during 'entry' mode.
- **Bell and LED Panel Integration:**
  - Programmed bell tones for patient notifications.
  - Synchronized LED flashing with bell tones for enhanced visibility.
- **Doctor Button Functions:**
  - Implemented "Next Patient" button functionality, including tone and LED synchronization.
  - Developed logic for handling the "Cancel Appointment" button and updating patient details.
- **Prototyping and Testing:**
  - Integrated all functionalities.
  - Conducted user testing to refine input handling and display updates.
  - Verified doctor button interactions in different kiosk modes.

---

### B. Justification of Design and Engineering Choices

#### 1. Keypad Input Handling

- **Mobile-Style Input Method:**
  - Chosen for its familiarity to users, reducing the learning curve.
  - Efficient use of a limited keypad to enter alphabetical characters.

- **Key Scanning Logic:**
  - Implemented a matrix scanning approach for the 4x4 keypad.
  - Included debounce logic to prevent false triggers.

#### 2. Special Key Functions

- **Backspace and Clear:**
  - Added for user convenience, allowing correction of input mistakes.
  - Enhances user experience by providing control over input.

- **Confirmation Key ('D'):**
  - Ensures that users have completed their input before proceeding.
  - Prevents accidental submissions.

#### 3. LCD Display Control

- **Clear Prompts and Messages:**
  - Designed user-friendly messages to guide patients through the process.
  - Used the first line for instructions and the second line for input/output.

- **Patient Information Display:**
  - Aligned text for readability, with names on the left and numbers on the right.
  - Consistent formatting aids in quick comprehension.

#### 4. Dual LCD Synchronization

- **Selective Update Mechanism:**
  - Utilized the LCD strobe signal to control updates to the secondary LCD.
  - In 'display' mode, both LCDs receive updates; in 'entry' mode, only the primary LCD updates.

- **Privacy Considerations:**
  - Prevented patient names entered during 'entry' mode from appearing on the secondary LCD.
  - Ensured compliance with privacy standards in a clinical setting.

#### 5. Bell and LED Panel Integration

- **Auditory and Visual Reminders:**
  - Synchronized bell tones and LED flashes to ensure clear and effective notifications.
  - Supported three distinct bell tones to differentiate between events, such as next patient calls or cancellations.

- **Wait Time Representation:**
  - Designed LED logic to visually represent remaining consultation time.
  - Enabled patients to gauge their waiting time easily, enhancing overall experience.

#### 6. Doctor Button Functions

- **Next Patient Button (PB0):**
  - Integrated visual (LED) and auditory (bell) cues for effective notifications.
  - Included safeguards to preserve kiosk input states during patient updates.
  
- **Cancel Appointment Button (PB1):**
  - Designed to manage no-shows with clear tones and display updates.
  - Maintains smooth operation without disrupting the patient queue.

#### 7. System Integration and Testing

- **Modularity:**
  - Divided functionalities (keypad, LCD, bell, LED) into modular components for streamlined integration and debugging.

---

### C. High-Level Pseudocode of the Overall Design

```plaintext
Initialize System:
  - Set keypad rows as inputs and columns as outputs.
  - Set buttons(PB0, PB1) as inputs.
  - Set LED Panel as outputs.
  - Set bell as output.
  - Initialize timer for interrupts.
  - Initialize LCD displays (primary and secondary).
  - Set the system mode to 'display'.
  - Set the doctor mode to 'idle'.

Main Loop:


  - If mode is 'display':
    - Show the next patient on both LCDs.
    - Listen for key 'A' to switch to 'entry' mode.

  - If mode is 'entry':
    - Display 'Enter Name:' prompt on primary LCD.
    - Read keypad inputs:
      - For keys 2–9:
        - Map key presses to corresponding letters.
        - Handle multiple presses for character selection.
        - Display the selected character on the primary LCD.
      - For key 'B':
        - Remove the last character entered.
      - For key 'C':
        - Clear all input.
      - For key 'D':
        - Confirm input and assign patient number.
        - Display confirmation message.
        - Wait for acknowledgment (press 'D' again).
        - Return to 'display' mode.

  - During 'entry' mode:
    - Secondary LCD maintains previous 'display' content.

  - If doctor mode is 'idle':
      - If PB0 (Next Patient) is pressed and the patient queue is not empty: 
        - Update patient queue.
        - Display next patient.
        - Set the doctor mode to 'waiting'.

  - If doctor mode is 'waiting':
    - If PB0 (Next Patient) is long-pressed (based Timer):  
      - Set the doctor mode to 'idle'.
      - If the patient queue is not empty: 
        - Display next patient.

    - If PB1 (Cancel Appointment) is long-pressed (based Timer):  
      - Cancel current patient’s appointment.   
      - Play "Bee...eep" tone. 
      - Set the doctor mode to 'idle'.
      - If the patient queue is not empty: 
        - Update patient queue
        - Display next patient.
        - Set the doctor mode to 'waiting'.

Keypad Input Handling:
  - Scan keypad matrix.
  - Debounce inputs.
  - Detect key presses and releases.
  - Handle character mapping and cycling.

LCD Display Control:
  - Send commands and data to LCDs.
  - Manage cursor positions.
  - Update display content based on current mode.

Dual LCD Synchronization:
  - Use LCD strobe control to manage updates.
  - In 'display' mode:
    - Enable updates to both LCDs.
  - In 'entry' mode':
    - Disable updates to the secondary LCD.
    - Preserve its current display.

LED Panel and Bell Control:
  - If doctor mode is 'idle':
    - Update LED panel based on remaining consultation time (based Timer).

  - If doctor mode is 'waiting':
    - Play "Beep-beep" tone for 10 seconds once (based Timer).
    - Play "Bip-bip" tone until doctor's next action (based Timer). 
    - Synchronize bell tones and LED flashes.

Display next patient:
  - Temporary switch to 'display' mode if needed.
  - Resumption of 'entry' mode with preserved input.

Timer Interrupt Handling:
  - Record the durations of buttons press.
  - Automatically completing input after inactivity.
  - LED panel and bell timing.
```

---

By focusing on these key areas, we have developed a user-friendly kiosk that simplifies the patient check-in process, ensuring efficiency and privacy in your clinic's operations.